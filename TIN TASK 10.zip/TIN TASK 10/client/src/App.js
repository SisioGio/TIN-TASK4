// client/src/App.js

import React from "react";
import "./App.css";
import Header from './components/partials/header'
import Table from './components/tables/users'
import Dashboard  from "./components/tables/dashboard";
function App() {

  return (
    <div className="App">
      <Header/>


      <Dashboard/>
    </div>
  );
}

export default App;