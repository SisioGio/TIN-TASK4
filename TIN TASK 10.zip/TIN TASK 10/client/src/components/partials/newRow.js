// client/src/App.js

import React from "react";
import { useState } from "react";
import moment from 'moment';
import axios from "axios";
import InputField from './input'



function NewRow(props) {
   const[isEditable,setIsEditable]= useState(false);
   const[formData,setFormData] = useState(props.generateTableForm(null))
   const[columns,setColumns] = useState(props.columns)

   const addRow = (event) =>{

    event.preventDefault();
    const form = new FormData();
    
    columns.map(column =>{
        if(column.disabled === false ){
            console.log("Adding " + formData[column.name])
            if(column.type==="date"){
                form.append(column.name,moment(formData[column.name]).format('yyyy-MM-DD'))
            }else{
                form.append(column.name,formData[column.name])
            }
            
        }
    })

    axios.post("/api/"+props.table+"/", form,
    {headers: {
                    'Content-Type':'application/json'
                }
    })  
    .then((res) => {
            console.log(res)
            props.getData();
            setFormData(props.generateTableForm(null))
            console.log("New form is: ")
            console.log(formData)
    })
    .catch((err) => {
    
        console.log(err.response.data)
    })
   
    setIsEditable(false)

   
}

    // Update formData on input change
  function handleChange(event) { 
    const {value, name} = event.target
    if(event.target.type=="checkbox"){
        
        let checkBoxValue = event.target.checked ? "checked":""
      
    setFormData(prevNote => ({
        
        ...prevNote, [name]: checkBoxValue})
    )
    } else{
        
        setFormData(prevNote => ({
        
            ...prevNote, [name]: value})
        )
    }
    
}
React.useEffect(()=>{
    setColumns(props.columns)

},[props.columns])


  return (

        <tr>




{props.columns.map(column =>{
                     return(
                    
                        <InputField 
                                onChange={handleChange} 
                                type={column.type} 
                                disabled={column.disabled} 
                                name={column.name} 
                                value={column.type==="datetime-local"?(moment().format('yyyy-MM-DD hh:mm:ss')) : (column.type==="date"? (moment(formData.birthDate).format('yyyy-MM-DD')):formData[column.name])}  placeholder={column.placeholder}/>
                     )
                    
                  })}
    
                <td>
                        <button onClick={addRow}>Save</button>
                </td> 
         
          
        </tr>
                                
                           
                      
    )
            


}

export default NewRow;