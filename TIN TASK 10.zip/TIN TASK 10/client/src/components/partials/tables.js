// client/src/App.js

import React from "react";


function Tables(props) {
   
   
  return (
  
   <div id='tables'>

      <div onClick={()=>props.updateData("user")} className="tables-item">

         Users
      </div>
   
      <div onClick={()=>props.updateData("product")} className="tables-item">

      Products
      </div>
     
   </div>



  );
}

export default Tables;