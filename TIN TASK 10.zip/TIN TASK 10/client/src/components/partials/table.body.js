
import React from "react";
import TableRow from './row'
import NewRow from './newRow'
import { useState } from "react";
import { useEffect } from "react";
function TableBody(props) {
const[rows,setRows] = useState(props.rows)

React.useEffect(()=>{


},[props.rows])
  return (

           
           <tbody>
 {props.rows.map(function(row,i){
return(

   
    <TableRow mykey = {i} row={row} columns={props.columns}  table={props.table} generateTableForm={props.generateTableForm} getData={props.getData} />
)
})}

{props.columns?(
    <NewRow  columns={props.columns}  table={props.table} generateTableForm={props.generateTableForm} getData={props.getData}/>
):(null)}


           </tbody>
        
  );
}

export default TableBody;