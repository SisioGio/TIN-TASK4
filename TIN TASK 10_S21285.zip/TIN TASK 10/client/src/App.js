// client/src/App.js

import React, { useReducer, createContext, useContext } from "react";
import "./App.css";
import Header from './components/partials/header'
import Dashboard  from "./components/tables/dashboard";
import Feedback from "./components/partials/feedback";
const showContext = createContext();
const dispatchContext = createContext();

const reducer = (state, action) => {
 
    
      return {action:action.value,message:action.message,title:action.title,type:action.type};
 
};
const states = {
  value: false,
  message:'',
  title:'',
  type:'',
};

function App() {
  const [state, dispatch] = useReducer(reducer, states);

  return (
    <dispatchContext.Provider value={dispatch}>
      <showContext.Provider value={state}>
<div className="App">
      <Header/>


      <Dashboard/>
    </div>
    </showContext.Provider>
    </dispatchContext.Provider>
    
  );
}

export default App;

export const dispatchContexts = () => useContext(dispatchContext);
export const showContexts = () => useContext(showContext);
