// client/src/App.js

import React from "react";
import logo from './../../images/ether_logo.png'


function Header() {
  

  return (
    <div id="nav-container">
    <nav>
       <div id="logo">
          <div >
            <img  src={logo} alt="TIN10 Logo"></img>
         
          </div>
          <label >Juventus Shop</label>
       </div>
       <div className="toggle-nav untoggled">
          <span></span>
          <span></span>
          <span></span>
       </div>
       <ul id="nav-links" className="nav-hidden">
          <li>
             <a href="#">Home</a>
          </li>
          <li>
            <a href="#">Docs</a>
         </li>
         <li>
             <a href="#about">About</a>
          </li>
          <li>
             <a href="#shop">Products</a>
          </li>
          <li>
             <a href="#">Account</a>
          </li> 
       </ul>
    </nav>
 </div>


  );
}

export default Header;