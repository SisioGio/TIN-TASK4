const dbConfig = require("../db.config.js");
const functions = require("./models.functions")
const mysql = require("mysql");
const connection = mysql.createConnection( {
  host: dbConfig.HOST,
  user: dbConfig.USER,
  password: dbConfig.PASSWORD,
  database:dbConfig.DB,


});

const INSERT = function(textToDIsplay){
  console.log(textToDIsplay)
}

async function SHOW_TABLES(){
  var output = []
  await connection.query("SHOW TABLES",function(err,result,fields){
    if(err) {
      console.log("Error while retrieving tables...")
      throw err;
    };
    console.log(result)
    output=result
      
  });
  return output 
}

const db = {};

db.SHOW_TABLES = SHOW_TABLES;
db.INSERT = INSERT;
db.connection = connection;
db.users = require("./model.user.js");



module.exports = db;