module.exports = (connection) => {


  // const Size = sequelize.define("sizes", {
  //   name: {
  //     type: Sequelize.STRING,
  //     allowNull: false
  //   }
  // });

  return Size}

