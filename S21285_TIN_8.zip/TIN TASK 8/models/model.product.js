module.exports = (connection) => {

 
  

  return Product}

