module.exports = () => {


  const createRow = function(){


    console.log("Hello!")
  }

  const queryAll = function(){
    console.log("Hello from query All")
  }

  return createRow}

