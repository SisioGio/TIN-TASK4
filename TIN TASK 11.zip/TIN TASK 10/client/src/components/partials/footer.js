

import React from "react";

function Footer() {


  return (



    <footer>
        <div id="footer-content">
        <div className="" id="social">
            <a href="#@JuventusEthShop" ><i className="fa fa-instagram" ></i></a>
            <a href="#@JuventusEthShop" ><i className="fa fa-facebook" ></i></a>
            <a href="#@JuventusEthShop" ><i className="fa fa-twitter" ></i></a>
            <a href="#@JuventusEthShop" ><i className="fa fa-envelope" ></i></a>
            <a href="#@JuventusEthShop" ><i className="fa fa-phone" ></i></a>
         </div>
         <h5>Developed by @Alessio Giovannini</h5>
         <h5>Via S. Agostino 42, 01100, Viterbo (VT)</h5>
        </div>
        
      </footer>
        
   

  );
}

export default Footer;