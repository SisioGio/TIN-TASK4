// client/src/App.js


import React, { useState } from "react";

function NotFound() {


  return (
  
  <div>
    <div class="spacerXL"></div>
    <h1>404 - SORRY</h1>
    <p>We couldn't find this page. Try to look for another one</p>
  </div>


  );
}

export default NotFound;