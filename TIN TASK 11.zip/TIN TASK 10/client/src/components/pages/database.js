// client/src/App.js


import React, { useState } from "react";

function Database() {


  return (
  
  <div>
    <h1>Database</h1>
  </div>


  );
}

export default Database;